const express = require('express');
const bodyParser = require('body-parser');
const path = require('path');
const app = express();
const cookieParser = require('cookie-parser');
const bcrypt = require('bcrypt');
const port = 8080;

// Middleware
console.log("TRACE: #1")
app.use(bodyParser.urlencoded({ extended: true }));

// Serve static files from the views directory for styles.css
console.log("TRACE: #2")
app.use(express.static(path.join(__dirname, 'views')));

// Set EJS as the templating engine
console.log("TRACE: #3")
app.set('view engine', 'ejs');

// In-memory storage for posts
console.log("TRACE: #4")
let posts = [];

// Routes
console.log("TRACE: #5")
app.get('/', (req, res) => {
  res.render('index', { posts });
});

console.log("TRACE: #6")
app.post('/create', (req, res) => {
  const { title, content } = req.body;
  const newPost = { title, content, date: new Date() };
  posts.push(newPost);
  res.redirect('/');
});

console.log("TRACE: #7")
app.get('/login', (req, res) => {
  res.render('login_out')
});

console.log("TRACE: #8")
// 渲染 success 页，受 checkAuth 中间件保护
app.get('/success', checkAuth, (req, res) => {
  res.render('success', { user: req.session.user });
});

console.log("TRACE: #9")
// 渲染 admin 页，受 checkAuth 中间件保护
app.get('/admin', checkAuth, (req, res) => {
  res.render('admin', { user: req.session.user });
});

console.log("TRACE: #10")
app.post('/signup', async (req, res) => {
  const { username, email, password } = req.body;
  console.log(req);
  try {
    const existingUser = await User.findOne({ email });
    if (existingUser) {
      return res.status(400).json({ message: 'User already exists' });
    }
    const hashedPassword = await bcrypt.hash(password, 10); // 哈希化密码
    const newUser = new User({
      _id: uuidv4(), // 设置 _id 为 UUID
      email,
      username,
      password: hashedPassword,
      admin: false, // 默认管理员为 false
      datetime: new Date() // 设置 datetime 为当前时间
    });
    await newUser.save();
    res.redirect('/'); // 成功注册后重定向到首页
  } catch (error) {
    res.status(400).send('Error registering user: ' + error.message);
  }
});


console.log("TRACE: #11")
app.post('/login', async (req, res) => {
  const { email, password } = req.body;
  try {
    const user = await User.findOne({ email });
    if (user) {
      const isMatch = await bcrypt.compare(password, user.password);
      if (isMatch) {
        req.session.user = user._id; // 存储 UUID 到 session
        const hashedUuid = await bcrypt.hash(user._id, 10); // 哈希化 UUID
        res.cookie('user', hashedUuid, { maxAge: 24 * 60 * 60 * 1000, httpOnly: true }); // 存储哈希化后的 UUID 到 cookie，有效期一天

        // 根据用户角色重定向
        if (user.admin) {
          res.redirect('/admin'); // 重定向到 admin 页
        } else {
          res.redirect('/success'); // 重定向到 success 页
        }
      } else {
        res.status(400).json({ message: 'Invalid email or password' }); // 返回 JSON 响应
      }
    } else {
      res.status(400).json({ message: 'Invalid email or password' }); // 返回 JSON 响应
    }
  } catch (error) {
    res.status(400).send('Error logging in: ' + error.message);
  }
});

console.log("TRACE: #12")
app.post('/logout', (req, res) => {
  req.session.destroy(err => {
    if (err) {
      console.log('Failed to destroy session:', err);
      return res.redirect('/admin');
    }
    res.clearCookie('user');
    res.render('logout');
  });
});

// Start the server
app.listen(port, () => {
  console.log(`Server is running on http://localhost:${port}`);
});


const mongoose = require('mongoose');
const { v4: uuidv4 } = require('uuid');
const uri = "mongodb+srv://www-data:RBFarENUKSNgpAVg@cluster0.talem.mongodb.net/";
const dbName = "project";

mongoose.connect(`${uri}${dbName}`)
.then(() => console.log("Successfully connected to the db"))
.catch(err => console.log("Failed to connect to the db", err));

app.set('view engine', 'ejs');

const blogSchema = new mongoose.Schema({
    _id: {
        type: String,
        default: uuidv4
    },
    user_id: {
        type: String,
        required: true
    },
    title: {
        type: String,
        required: true
    },
    content: {
        type: String,
        required: true
    },
    datetime: {
        type: String
    }
}, { collection: 'blog' });

const userSchema = new mongoose.Schema({
  _id: { type: String, default: uuidv4 }, // 将 _id 设置为 UUID
  email: { type: String, unique: true },
  username: String,
  password: String,
  admin: { type: Boolean, default: false }, // 默认值为 false
  datetime: { type: Date, default: Date.now } // 添加 datetime 字段，默认值为当前时间
}, { collection: 'user' }); // 指定集合名称为 'user'

console.log("TRACE: #13")
function checkAuth(req, res, next) {
  if (req.session.user && req.cookies.user) {
    // 检查 session 和 cookie 是否匹配
    bcrypt.compare(req.session.user, req.cookies.user, (err, isMatch) => {
      if (isMatch) {
        return next(); // 继续到下一个中间件或路由处理程序
      } else {
        // 销毁 session 并清除 cookie
        req.session.destroy(err => {
          if (err) {
            console.log('Failed to destroy session:', err);
            return res.redirect('/');
          }
          res.clearCookie('user');
          res.redirect('/');
        });
      }
    });
  } else {
    res.redirect('/');
  }
}





const Blog = mongoose.model('Blog', blogSchema);
const User = mongoose.model('User', userSchema);
app.get('/blogs', async (req, res) => {
    try {
      const blogCollection = mongoose.connection.collection('blog');
      const aggregationResult = await blogCollection.aggregate([
  {
    $lookup: {
      from: 'user',
      localField: 'user_id',
      foreignField: '_id',
      as: 'userdetails'
    }
  },
  { $unwind: '$userdetails' },
  {
    $project: {
      title: 1,
      content: 1,
      channel :1,
      datetime: 1,
      'userdetails.username': 1
    }
  }
]).toArray();
        console.log(aggregationResult)
        res.render('list', { blogs: aggregationResult});
    } catch (err) {
        res.status(500).send(err);
    }
});

app.get('/blogs/:id', async (req, res) => {
    try {
        const blog = await Blog.findById(req.params.id);
        if (!blog) {
            return res.status(404).send('Blog not found');
        }
        
        res.render('details', { blog: blog });
    } catch (err) {
        res.status(500).send(err);
    }
});

app.get('/search', async (req, res) => {
    const query = req.query.query;
    if (!query) {
        return res.redirect('/blogs');
    }
    try {
          const blogCollection = mongoose.connection.collection('blog');
                const aggregationResult = await blogCollection.aggregate([
            {
              $lookup: {
                from: 'user',
                localField: 'user_id',
                foreignField: '_id',
                as: 'userdetails'
              }
            },
            { $unwind: '$userdetails' },
            {
              $project: {
                title: 1,
                content: 1,
                channel :1,
                datetime: 1,
                'userdetails.username': 1
              }
            }
          ]).toArray();


              const blogs = await Blog.find({
                  $or: [
                      { title: { $regex: query, $options: 'i' } },
                      { content: { $regex: query, $options: 'i' } }
                  ]
              });
              console.log(aggregationResult);
        res.render('list', { blogs: aggregationResult });
    } catch (err) {
        res.status(500).send(err);
    }
});
